import { useState } from 'react'
import Header from './components/Header'
import InputMonitor from './components/InputMonitor'
import IngestSchedule from './components/IngestSchedule'
import IngestHistory from './components/IngestHistory'
import ActiveRecordings from './components/ActiveRecordings'
import ActiveRecording from './components/ActiveRecording'
import ProxyQueue from './components/ProxyQueue'
import { ThemeProvider } from './ThemeContext'

function App() {
  return (
    <ThemeProvider>
      <div className="min-h-screen bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-white transition-colors duration-300">
        <div className="container mx-auto px-4 py-6">
          <Header />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
            <div className="space-y-6">
              <InputMonitor />
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                <ActiveRecordings />
                <ActiveRecording />
              </div>
            </div>
            
            <div className="space-y-6">
              <IngestSchedule />
              <IngestHistory />
              <ProxyQueue />
            </div>
          </div>
        </div>
      </div>
    </ThemeProvider>
  )
}

export default App
