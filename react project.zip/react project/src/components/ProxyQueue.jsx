import React from 'react';

const ProxyQueueItem = ({ title, progress, quality }) => {
  const getProgressColor = (progress) => {
    if (progress < 30) return 'bg-red-500';
    if (progress < 70) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  return (
    <div className="card hover:bg-gray-700 transition-colors cursor-pointer">
      <div className="flex justify-between items-center mb-2">
        <h3 className="font-medium">{title}</h3>
        <span className="text-sm">{progress}%</span>
      </div>
      <div className="w-full h-2 bg-gray-700 rounded-full mb-2">
        <div 
          className={`h-full rounded-full ${getProgressColor(progress)}`}
          style={{ width: `${progress}%` }}
        ></div>
      </div>
      <div className="flex justify-between items-center">
        <div className="flex items-center">
          {quality === 'active' && (
            <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
          )}
          {quality === 'pending' && (
            <span className="w-2 h-2 bg-red-500 rounded-full mr-2"></span>
          )}
        </div>
        <span className="text-sm text-gray-400">{quality === 'active' ? '720 p' : '1080 p'}</span>
      </div>
    </div>
  );
};

const ProxyQueue = () => {
  const queueItems = [
    { id: 1, title: 'Clip C', progress: 50, quality: 'active' },
    { id: 2, title: 'Clip D', progress: 0, quality: 'pending' },
    { id: 3, title: 'News Segment', progress: 0, quality: 'pending' },
  ];

  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">PROXY QUEUE</h2>
      
      <div className="space-y-3">
        {queueItems.map((item) => (
          <ProxyQueueItem 
            key={item.id}
            title={item.title}
            progress={item.progress}
            quality={item.quality}
          />
        ))}
      </div>
    </div>
  );
};

export default ProxyQueue;
