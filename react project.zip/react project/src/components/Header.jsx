import React, { useState } from 'react';
import ThemeToggle from './ThemeToggle';
import AnimatedLogo from './AnimatedLogo';

const Header = () => {
  const [source, setSource] = useState('All Sources');
  const [inputType, setInputType] = useState('');

  return (
    <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
        <div className="flex flex-col">
          <AnimatedLogo />
          <span className="text-xs text-gray-500 dark:text-gray-400 ml-10 -mt-1">
            Intelligent Video Ingest Platform
          </span>
        </div>
        
        <div className="relative">
          <label className="block text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Source</label>
          <div className="relative">
            <select 
              className="appearance-none block w-48 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-md py-2 px-3 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 hover:border-blue-500 transition-colors duration-200"
              value={source}
              onChange={(e) => setSource(e.target.value)}
            >
              <option>All Sources</option>
              <option>Live Input</option>
              <option>File Input</option>
              <option>Remote Sources</option>
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-500 dark:text-gray-400">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
              </svg>
            </div>
          </div>
        </div>
        
        <div className="relative">
          <label className="block text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Input Type</label>
          <div className="relative">
            <select 
              className="appearance-none block w-48 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-md py-2 px-3 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 hover:border-blue-500 transition-colors duration-200"
              value={inputType}
              onChange={(e) => setInputType(e.target.value)}
            >
              <option value="">All Types</option>
              <option value="sdi">SDI</option>
              <option value="hdmi">HDMI</option>
              <option value="ndi">NDI</option>
              <option value="rtmp">RTMP</option>
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-500 dark:text-gray-400">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
              </svg>
            </div>
          </div>
        </div>
      </div>

      <div className="flex items-center space-x-4">
        <ThemeToggle />
        <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-md flex items-center space-x-2 transition-all duration-300 hover:shadow-lg hover:scale-105 text-white">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
          </svg>
          <span>Schedule Ingest</span>
        </button>
      </div>
    </header>
  );
};

export default Header;
