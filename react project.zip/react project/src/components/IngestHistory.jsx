import React from 'react';

const IngestHistory = () => {
  const historyItems = [
    { id: 1, title: 'News Intro', date: '18 Apr 2024' },
    { id: 2, title: 'Event Highlights', date: '17 Apr 2024' },
    { id: 3, title: 'Studio A Live', date: '15 Apr 2024' },
  ];

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">INGEST HISTORY</h2>
        <a href="#" className="text-blue-400 hover:text-blue-300 text-sm">VIEW ALL</a>
      </div>
      
      <div className="space-y-3">
        {historyItems.map((item) => (
          <div key={item.id} className="card hover:bg-gray-700 transition-colors cursor-pointer">
            <div className="flex justify-between items-center">
              <h3 className="font-medium">{item.title}</h3>
              <p className="text-sm text-gray-400">{item.date}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default IngestHistory;
