import React from 'react';

const ActiveRecordings = () => {
  const recordings = [
    { 
      id: 1, 
      title: '01: 02:57', 
      studio: 'Studio A', 
      source: 'Ingest Input 5',
      url: 'rtmp://192.168.1.50/live/studio',
      inputType: '3416 kb/s',
      bitrate: '3416 kb/s'
    }
  ];

  return (
    <div className="transition-all duration-300">
      <h2 className="text-xl font-semibold mb-4 text-gray-800 dark:text-white">ACTIVE RECORDINGS</h2>
      
      <div className="space-y-3">
        {recordings.map((recording) => (
          <div key={recording.id} className="card hover-scale hover-shadow cursor-pointer">
            <div className="flex justify-between items-center mb-2">
              <div className="flex items-center">
                <span className="status-indicator status-active"></span>
                <h3 className="font-medium">{recording.title}</h3>
              </div>
              <span className="text-sm text-gray-500 dark:text-gray-400">{recording.studio}</span>
            </div>
            
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">{recording.source}</p>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">{recording.url}</p>
            
            <div className="grid grid-cols-2 gap-4 mt-3">
              <div>
                <span className="text-xs text-gray-500 dark:text-gray-400">Input Type</span>
                <p className="text-sm">{recording.inputType}</p>
              </div>
              <div>
                <span className="text-xs text-gray-500 dark:text-gray-400">Bitrate</span>
                <p className="text-sm">{recording.bitrate}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ActiveRecordings;
