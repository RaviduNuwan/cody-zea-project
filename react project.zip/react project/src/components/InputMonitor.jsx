import React from 'react';

const InputCard = ({ inputNumber, status, inputSource }) => {
  const statusClass = 
    status === 'active' ? 'status-active' : 
    status === 'no-signal' ? 'status-inactive' : 
    status === 'signal' ? 'status-active' : 'status-warning';

  return (
    <div className="card hover-scale hover-shadow cursor-pointer">
      <div className="flex items-center mb-2">
        <span className={`status-indicator ${statusClass}`}></span>
        <h3 className="font-medium">Input {inputNumber}</h3>
      </div>
      <p className="text-sm text-gray-500 dark:text-gray-400">{inputSource}</p>
    </div>
  );
};

const InputMonitor = () => {
  const inputs = [
    { id: 1, number: 1, status: 'active', source: 'Input 2' },
    { id: 2, number: 3, status: 'active', source: 'Input 6' },
    { id: 3, number: 9, status: 'active', source: 'Input 8' },
    { id: 4, number: 'No Signal', status: 'no-signal', source: 'Input 4' },
    { id: 5, number: 4, status: 'active', source: 'Input 7' },
    { id: 6, number: 'No Signal', status: 'no-signal', source: 'Input 5' },
    { id: 7, number: 'Signal', status: 'signal', source: 'Input 8' },
    { id: 8, number: 6, status: 'active', source: 'Input 6' },
    { id: 9, number: 11, status: 'active', source: 'Input 10' },
    { id: 10, number: 11, status: 'active', source: 'Input 9' },
    { id: 11, number: 12, status: 'active', source: 'Input 11' },
    { id: 12, number: 12, status: 'active', source: 'Input 12' },
  ];

  return (
    <div className="transition-all duration-300">
      <h2 className="text-xl font-semibold mb-4 text-gray-800 dark:text-white">INPUT MONITOR</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {inputs.map((input) => (
          <InputCard 
            key={input.id}
            inputNumber={input.number}
            status={input.status}
            inputSource={input.source}
          />
        ))}
      </div>
    </div>
  );
};

export default InputMonitor;
