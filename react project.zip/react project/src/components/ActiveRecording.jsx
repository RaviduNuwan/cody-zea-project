import React from 'react';

const ActiveRecording = () => {
  const recording = {
    id: 1,
    title: 'Studio A Live',
    inputs: [
      { id: 1, name: 'Input 5', selected: true },
      { id: 2, name: 'Input 6', selected: false }
    ],
    audioSource: 'Tane Mah.',
    date: '17 Apr 2024',
    inputs2: [
      { id: 1, name: 'Input 9', selected: true },
      { id: 2, name: 'Input 3', selected: false },
      { id: 3, name: 'Input 9', selected: true }
    ]
  };

  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">ACTIVE RECORDING</h2>
      
      <div className="card hover:bg-gray-700 transition-colors cursor-pointer">
        <div className="flex items-center mb-3">
          <span className="status-indicator status-active"></span>
          <h3 className="font-medium">{recording.title}</h3>
        </div>
        
        <div className="flex flex-wrap gap-2 mb-3">
          {recording.inputs.map((input) => (
            <span 
              key={input.id} 
              className={`py-1 px-3 rounded-full text-xs ${input.selected ? 'bg-blue-700 text-white' : 'bg-gray-700 text-gray-300'}`}
            >
              {input.name}
            </span>
          ))}
        </div>
        
        <div className="flex justify-between items-center mb-3">
          <span className="text-sm text-gray-400">{recording.audioSource}</span>
        </div>
        
        <div className="flex items-center">
          <svg className="w-5 h-5 text-gray-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
          </svg>
          <span className="text-sm text-gray-400">{recording.date}</span>
        </div>
        
        <div className="flex flex-wrap gap-2 mt-3">
          {recording.inputs2.map((input) => (
            <span 
              key={input.id} 
              className={`py-1 px-3 rounded-full text-xs ${input.selected ? 'bg-blue-700 text-white' : 'bg-gray-700 text-gray-300'}`}
            >
              {input.name}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ActiveRecording;
