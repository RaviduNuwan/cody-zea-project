import React from 'react';

const AnimatedLogo = () => {
  return (
    <div className="flex items-center mr-4">
      <div className="relative w-8 h-8 mr-2 hover-scale">
        <div className="absolute inset-0 bg-blue-500 rounded-md transform transition-all duration-300 hover:rotate-45"></div>
        <div className="absolute inset-1 bg-blue-700 rounded-sm transform transition-all duration-300 hover:-rotate-45"></div>
        <div className="absolute inset-2 bg-blue-900 rounded-sm flex items-center justify-center">
          <span className="text-white text-xs font-bold">CZ</span>
        </div>
      </div>
      <div className="font-bold text-xl text-gray-800 dark:text-white transition-colors duration-300">
        <span className="bg-gradient-to-r from-blue-600 to-blue-400 bg-clip-text text-transparent">CODY ZEA</span>
      </div>
    </div>
  );
};

export default AnimatedLogo;
