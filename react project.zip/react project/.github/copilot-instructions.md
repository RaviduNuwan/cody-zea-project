<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

# Video Ingest Dashboard Project Instructions

This project is a React application using Tailwind CSS for a video ingest and monitoring dashboard.

## Project Structure

- `src/components/`: Contains all React components
- `src/index.css`: Contains global styles and Tailwind imports
- `tailwind.config.js`: Tailwind CSS configuration

## Coding Standards

- Follow React best practices for functional components and hooks
- Use ES6+ JavaScript syntax
- Maintain responsive design across all components
- Follow the existing dark theme with blue accents
- Prefer Tailwind utility classes over custom CSS when possible
