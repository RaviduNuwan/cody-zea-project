# Video Ingest Dashboard

A modern, responsive dashboard for video ingest and monitoring built with React and Tailwind CSS.

## Features

- Input monitoring with status indicators
- Active recordings display
- Ingest scheduling
- Ingest history
- Proxy queue monitoring
- Modern, dark-themed UI

## Prerequisites

- Node.js (v14.0.0 or higher)
- npm (v6.0.0 or higher)

## Installation

1. Clone this repository
2. Install dependencies:

```bash
npm install
```

## Development

To run the development server:

```bash
npm run dev
```

This will start the application at `http://localhost:5173`.

## Building for Production

To build the application for production:

```bash
npm run build
```

## Customize

- Modify components in the `src/components` directory
- Update styles in `src/index.css` 
- Configure Tailwind in `tailwind.config.js`
